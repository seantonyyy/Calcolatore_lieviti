rootProject.name = "CalcolatoreLieviti"
include(":app")
