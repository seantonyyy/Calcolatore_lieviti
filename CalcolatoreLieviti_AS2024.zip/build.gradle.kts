plugins { `java-library` }
allprojects { repositories { google(); mavenCentral() } }
